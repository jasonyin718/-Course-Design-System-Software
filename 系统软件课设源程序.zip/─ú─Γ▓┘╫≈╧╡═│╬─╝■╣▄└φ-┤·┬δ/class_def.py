class Content():
    def __init__(self):
        self.content_lst = []

    def set_content_lst(self, fcb):
        self.content_lst.append(fcb)


class FAT:
    def __init__(self):
        self.fat_lst = []
        self.fat_free_space_num = 508
        self.init_fat_lst()  # 将fat_lst的其余项都赋为0

    def init_fat_lst(self):
        self.fat_lst = [-1, -1, -1, -1]  # 前四项为系统占用，设置一个特殊值
        for i in range(4, 512):
            self.fat_lst.append(0)


class FCB:
    def __init__(self, file_name, start_addr, file_length, modify_time):
        self.file_name = file_name
        self.start_addr = start_addr
        self.file_length = file_length
        self.modify_time = modify_time
