import class_def as cd
import time as tm


class App:
    def __init__(self):
        self.my_content = cd.Content()
        self.my_fat = cd.FAT()

    # 运行主程序
    def run(self):
        while (1):
            self.output_func_list()
            self.func_num = self.input_fun_num()  # 功能号存储在func_num中
            self.op_func()  # 执行对应功能号的功能

    # 显示功能菜单
    def output_func_list(self):
        print("##################模拟DOS文件系统##################")
        print("1、创建文件\t2、删除文件\t3、文件追加\t4、文件截断\n5、文件改名\t6、拷贝文件\t7、显示FAT表\t8、显示目录\n0、退出程序")
        print("\t\t-----------------------------")
        print("\t" * 4 + "请输入功能号：", end=' ')

    # 输入功能号
    def input_fun_num(self):
        self.str_func_num = input()
        self.func_num = self.judge_isdigit(self.str_func_num)
        return self.func_num

    # 判断功能号是否合理
    def judge_isdigit(self, num_str):
        if num_str.isdigit():
            if 0 <= int(num_str) <= 8:
                return int(num_str)
            else:
                print("暂无对应功能号，请重新输入！")
        else:
            print("格式错误，请输入对应功能号数字！")

    # 根据文件名和文件长度创建文件名
    def cre_file(self):
        new_file_len_str = None
        exist = False
        while True:
            print("\t\t***********创建文件***********")
            print("\t" * 2 + "请输入文件名(输入q返回主菜单)：", end='')
            cre_file_name = input()  # 文件名
            if cre_file_name == 'q':  # 返回到主菜单
                self.run()
            print("\t" * 2 + "请输入文件长度：", end='')
            cre_file_len_str = input()
            # 判断文件是否存在
            if self.search_file(cre_file_name):
                print("\t\t文件“{}”已存在于系统中，是否要修改原文件名？(y/n)：".format(cre_file_name), end='')
                y_or_n = input()
                if y_or_n == 'y':
                    exist = True
                if y_or_n == 'n':
                    continue
            # 文件长度是否为数字、文件是否已经存在于系统中
            if not cre_file_len_str.isdigit() or exist:
                if not cre_file_len_str.isdigit():
                    print("格式错误，文件长度请输入数字！")
                    continue
                if exist:
                    self.modify_file(cre_file_name)
                    break
            else:
                last_pos = None  # 上一个记录的位置
                now_pos = None  # 当前记录的位置
                for start_addr in range(4, len(self.my_fat.fat_lst)):  # 确定文件的 第一块 在FAT表中的位置
                    if self.my_fat.fat_lst[start_addr] == 0:
                        self.my_content.set_content_lst(
                            cd.FCB(cre_file_name, start_addr, int(cre_file_len_str), tm.strftime("%Y/%m/%d %H:%M:%S")))
                        last_pos = start_addr
                        i = start_addr
                        while self.my_fat.fat_lst[i] != 0:
                            i += 1
                            break
                        now_pos = i
                        break
                cnt = 0
                while now_pos < len(self.my_fat.fat_lst) and cnt < int(cre_file_len_str):
                    if self.my_fat.fat_lst[now_pos] == 0:
                        now_pos = now_pos
                        self.my_fat.fat_lst[last_pos] = now_pos
                        last_pos = now_pos
                        self.my_fat.fat_free_space_num -= 1
                        cnt += 1
                    now_pos += 1
                self.my_fat.fat_lst[now_pos - 1] = 'FFF'
                self.my_fat.fat_free_space_num -= 1
                print("\t" * 2 + "成功创建文件，名称：{}，长度：{}".format(cre_file_name, int(cre_file_len_str)))
                break

    # 根据文件名删除文件
    def del_file(self):
        del_file_name = None
        while True:
            if del_file_name == 'q':
                break
            print("\t\t***********删除文件***********")
            print("\t\t请输入文件名(输入q返回主菜单)：", end='')
            del_file_name = input()  # 文件名
            if del_file_name == 'q':  # 返回到主菜单
                self.run()
            if not self.search_file(del_file_name):
                print("\t\t该文件不存在！")
            else:
                # 找到文件的start_addr
                for f_name in self.my_content.content_lst:
                    if f_name.file_name == del_file_name:
                        self.del_file_addr = f_name.start_addr
                pos = self.del_file_addr
                # 从FAT表中删除
                while self.my_fat.fat_lst[pos] != 'FFF':
                    next_pos = self.my_fat.fat_lst[pos]
                    self.my_fat.fat_lst[pos] = 0
                    pos = next_pos
                self.my_fat.fat_lst[pos] = 0
                # 从目录中删除文件
                for pos, file_fcb in enumerate(self.my_content.content_lst):
                    if file_fcb.file_name == del_file_name:
                        self.my_content.content_lst.pop(pos)
                        break
                print("\t\t已删除文件：{}".format(del_file_name))
                break

    # 在指定文件后面追加长度
    def append_file(self):
        while True:
            print("\t\t***********追加文件***********")
            need_append_file_name = input("\t\t请输入追加文件的文件名：")
            need_append_file_len_str = input("\t\t请输入追加的长度：")
            if need_append_file_name == 'q':  # 返回到主菜单
                self.run()
            if not need_append_file_len_str.isdigit():
                print("格式错误，请输入数字！")
                continue
            else:
                pos = 0
                last_pos = 0
                if self.search_file(need_append_file_name):
                    for file_fcb in self.my_content.content_lst:
                        if file_fcb.file_name == need_append_file_name:
                            pos = file_fcb.start_addr + file_fcb.file_length - 1
                            last_pos = pos
                            file_fcb.file_length += int(need_append_file_len_str)
                            file_fcb.modify_time = tm.strftime("%Y/%m/%d %H:%M:%S")
                            break
                    cnt = 0
                    #在原来FFF的位置放上
                    self.my_fat.fat_lst[pos] = 0
                    pos += 1
                    # 在FAT表中追加
                    while pos < len(self.my_fat.fat_lst) and cnt < int(need_append_file_len_str):
                        if self.my_fat.fat_lst[pos] == 0:
                            self.my_fat.fat_lst[last_pos] = pos
                            last_pos = pos
                            self.my_fat.fat_free_space_num -= 1
                            cnt += 1
                        pos += 1
                    self.my_fat.fat_lst[pos - 1] = 'FFF'
                    self.my_fat.fat_free_space_num -= 1
                    print("文件“{}”的长度已增加：{}".format(need_append_file_name, int(need_append_file_len_str)))
                    break
                else:
                    print("文件“{}”不存在，请重新输入！".format(need_append_file_name))
                    continue

    # 抛弃文件指定位置后的内容
    def cut_file(self):
        while True:
            print("\t\t***********截断文件***********")
            need_cut_file_name = input("\t\t请输入截断文件的文件名(输入q返回主菜单)：")
            need_cut_file_pos = input("\t\t请输入截断文件的位置：")
            if need_cut_file_name == 'q':
                self.run()
            if not need_cut_file_pos.isdigit():
                print("格式错误，请输入数字！")
                continue
            if int(need_cut_file_pos) <= 0:
                print("截断位置错误，请输入大于0的整数！")
                continue
            else:
                if self.search_file(need_cut_file_name):
                    if int(need_cut_file_pos) == 1:
                        self.del_file()
                        break
                    # 从目录中改变该文件的文件长度
                    pos = 0
                    for file_fcb in self.my_content.content_lst:
                        if file_fcb.file_name == need_cut_file_name:
                            if int(need_cut_file_pos) > file_fcb.file_length:
                                print("位置{}大于文件“{}”的长度，无法截断！请重新输入。".format(int(need_cut_file_pos), need_cut_file_name))
                                continue
                            else:
                                pos = file_fcb.start_addr + int(need_cut_file_pos) - 1
                                file_fcb.file_length = int(need_cut_file_pos)
                                file_fcb.modify_time = tm.strftime("%Y/%m/%d %H:%M:%S")
                                break
                    # 从FAT表中改变该文件的记录
                    now_pos = self.my_fat.fat_lst[pos]
                    self.my_fat.fat_lst[pos] = 'FFF'
                    while self.my_fat.fat_lst[now_pos] != 'FFF':
                        tmp_pos = self.my_fat.fat_lst[now_pos]
                        self.my_fat.fat_lst[now_pos] = 0
                        now_pos = tmp_pos
                    self.my_fat.fat_lst[now_pos] = 0
                    print("已成功截断文件“{}”".format(need_cut_file_name))
                    break
                else:
                    print("文件“{}”不存在系统中！请重新输入。".format(need_cut_file_name))
                    continue

    # 截断文件中的特殊情况
    def special_cut(self, file_name):
        # 找到文件的start_addr
        for f_name in self.my_content.content_lst:
            if f_name.file_name == file_name:
                self.del_file_addr = f_name.start_addr
        pos = self.del_file_addr
        # 从FAT表中删除
        while self.my_fat.fat_lst[pos] != 'FFF':
            next_pos = self.my_fat.fat_lst[pos]
            self.my_fat.fat_lst[pos] = 0
            pos = next_pos
        self.my_fat.fat_lst[pos] = 0
        # 从目录中删除文件
        for pos, file_fcb in enumerate(self.my_content.content_lst):
            if file_fcb.file_name == file_name:
                self.my_content.content_lst.pop(pos)
                break

    # 根据文件名重命名文件
    def rename_file(self):
        while True:
            print("\t\t***********修改文件***********")
            file_old_name = input("\t\t请输入重命名的文件名：")
            file_new_name = input("\t\t请输入新文件名：")
            if not self.search_file(file_old_name):
                print("文件“{}”不存在，请重新输入！".format(file_old_name))
                continue
            else:
                for file_fcb in self.my_content.content_lst:
                    if file_fcb.file_name == file_old_name:
                        file_fcb.file_name = file_new_name
                        file_fcb.modify_time = tm.strftime("%Y/%m/%d %H:%M:%S")
                        print("已将文件“{}”重命名为“{}”".format(file_old_name, file_new_name))
                        break
            break

    # 根据文件名重命名文件
    def modify_file(self, file_old_name):
        while True:
            print("\t\t***********修改文件***********")
            file_new_name = input("\t\t请输入新文件名：")
            for file_fcb in self.my_content.content_lst:
                if file_fcb.file_name == file_old_name:
                    file_fcb.file_name = file_new_name
                    file_fcb.modify_time = tm.strftime("%Y/%m/%d %H:%M:%S")
                    print("已将文件“{}”重命名为“{}”".format(file_old_name, file_new_name))
                    break
            break

    # 根据文件名拷贝文件
    def copy_file(self):
        while True:
            print("\t\t***********拷贝文件***********")
            source_file_name = input("\t\t请输入要拷贝的文件名(输入q返回主菜单)：")
            if source_file_name == 'q':
                self.run()
            if self.search_file(source_file_name):
                dest_file_lenth = None
                dest_file_name = None
                # 从目录中找到源文件并copy其长度，并且设置目标文件的文件名
                for file_fcb in self.my_content.content_lst:
                    if file_fcb.file_name == source_file_name:
                        dest_file_lenth = file_fcb.file_length
                        dest_file_name = file_fcb.file_name + "COPY"
                last_pos = None  # 上一个记录的位置
                now_pos = None  # 当前记录的位置
                for start_addr in range(4, len(self.my_fat.fat_lst)):  # 确定文件的 第一块 在FAT表中的位置
                    if self.my_fat.fat_lst[start_addr] == 0:
                        self.my_content.set_content_lst(
                            cd.FCB(dest_file_name, start_addr, int(dest_file_lenth), tm.strftime("%Y/%m/%d %H:%M:%S")))
                        last_pos = start_addr
                        i = start_addr
                        while self.my_fat.fat_lst[i] != 0:
                            i += 1
                            break
                        now_pos = i
                        break
                cnt = 0
                while now_pos < len(self.my_fat.fat_lst) and cnt < int(dest_file_lenth):
                    if self.my_fat.fat_lst[now_pos] == 0:
                        now_pos = now_pos
                        self.my_fat.fat_lst[last_pos] = now_pos
                        last_pos = now_pos
                        self.my_fat.fat_free_space_num -= 1
                        cnt += 1
                    now_pos += 1
                self.my_fat.fat_lst[now_pos - 1] = 'FFF'
                self.my_fat.fat_free_space_num -= 1
                print("已成功拷贝文件“{}”".format(source_file_name))
                break
            else:
                print("文件“{}”不存在系统中！请重新输入。".format(source_file_name))

    # 显示FAT表
    def show_FAT(self):
        print("\t\t-----------显示FAT表-----------")
        print("\t0\t1\t2\t3\t4\t5\t6\t7\t8\t9")
        print("\t\t###############################")
        for i in range(0, len(self.my_fat.fat_lst), 10):
            j = 0
            if i + j < len(self.my_fat.fat_lst):
                while j < 10:
                    if i + j < len(self.my_fat.fat_lst):
                        print("\t{}".format(self.my_fat.fat_lst[i + j]), end='')
                    if j == 9:
                        print()
                    j += 1

    # 显示目录
    def show_content(self):
        print("\t\t***********目录显示***********")
        print("\t\t文件名\t\t起始地址\t\t文件长度\t\t最后修改日期")
        for fcb in self.my_content.content_lst:
            print("\t\t{}\t\t{}\t\t{}\t\t{}".format(fcb.file_name, fcb.start_addr, fcb.file_length, fcb.modify_time))

    # 查找文件是否存在
    def search_file(self, file_name):
        for i in self.my_content.content_lst:
            if i.file_name == file_name:
                return True
        return False

    # 退出程序
    def exit_app(self):
        print("\t" * 3 + "您已退出DOS文件系统模拟器！", end='')
        exit(0)

    # 执行用户输入的功能号
    def op_func(self):
        if self.func_num == 1:
            self.cre_file()
        elif self.func_num == 2:
            self.del_file()
        elif self.func_num == 3:
            self.append_file()
        elif self.func_num == 4:
            self.cut_file()
        elif self.func_num == 5:
            self.rename_file()
        elif self.func_num == 6:
            self.copy_file()
        elif self.func_num == 7:
            self.show_FAT()
        elif self.func_num == 8:
            self.show_content()
        elif self.func_num == 0:
            self.exit_app()


def main():
    my_app = App()
    my_app.run()


if __name__ == '__main__':
    main()
