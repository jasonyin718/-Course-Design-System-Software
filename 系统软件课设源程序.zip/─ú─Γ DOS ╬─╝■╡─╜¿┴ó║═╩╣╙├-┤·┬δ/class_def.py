import threading
import time as tm
import operation_file as of
import operation_revoke as ra
import operation_wait_task as ow


class zone:
    def __init__(self, start_address, length, state, name):
        self.start_address = start_address
        self.z_length = length
        self.state = state
        self.name = name

    def set_start_address(self, value):
        self.start_address = value

    def set_z_length(self, value):
        self.z_length = value

    def set_state(self, value):
        self.state = value

    def set_name(self, value):
        self.name = value

    def get_start_address(self):
        return self.start_address

    def get_z_length(self):
        return self.z_length

    def get_state(self):
        return self.state

    def get_name(self):
        return self.name


class task:
    def __init__(self, name, length, op_time):
        self.name = name
        self.t_length = length
        self.op_time = op_time

    def get_name(self):
        return self.name

    def get_t_length(self):
        return self.t_length

    def get_op_time(self):
        return self.op_time


# 在画布上显示运行时间
class timerThread(threading.Thread):
    def __init__(self, gui):
        threading.Thread.__init__(self)
        self.running = True
        self.gui = gui

    def ternimate(self):
        self.running = False

    def run(self):
        while self.running < 200:
            self.gui.now_time += 1
            time_text = self.gui.cvs2.create_text(60, 30, text='运行时间：' + str(self.gui.now_time) + '秒')
            tm.sleep(1)
            self.gui.update()
            self.gui.cvs2.delete(time_text)


class revokeThread(threading.Thread):
    def __init__(self, gui):
        threading.Thread.__init__(self)
        self.running = True
        self.gui = gui

    def ternimate(self):
        self.running = False

    def run(self):
        task_name = None
        has_found = False
        while len(self.gui.task_rect_text_lst) != 0:
            for task in self.gui.task_lst:
                self.gui.update()
                if task.get_op_time() == self.gui.now_time:
                    task_name = task.get_name()
                    has_found = True
                    break
            if has_found:
                has_found = False
                ra.revoke_in_cvs(self.gui, task_name)
                ra.revoke_in_DS(self.gui)
                if len(self.gui.wait_task_lst) != 0:
                    of.draw_wait_task(self.gui)
                    ow.put_history_on_win(self.gui)
                else:
                    self.gui.cvs1.destroy()
