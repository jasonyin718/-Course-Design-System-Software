'''
    这是在数据结构中以及在图形用户界面中分配空间的函数库
'''
import class_def as cd
import tool_function as tf


# 分配空间，both数据结构以及画布可视化
def allocate(gui):
    allocate_in_DS(gui)
    if gui.can_alloc:
        allocate_in_cvs(gui)


# 分配空间，在数据结构中分配
def allocate_in_DS(gui):
    if gui.is_first:
        gui.can_alloc = False
        '''为新作业分配空间'''
        for n_zone in gui.zone_lst:
            if n_zone.get_state() == 'free' and n_zone.get_z_length() >= gui.new_task.get_t_length():
                n_zone.set_state('used')
                if n_zone.get_z_length() == gui.new_task.get_t_length():
                    gui.can_alloc = True
                    n_zone.set_name(gui.new_task.get_name())
                if n_zone.get_z_length() > gui.new_task.get_t_length():
                    rest_z_length = n_zone.get_z_length() - gui.new_task.get_t_length()
                    rest_start_address = n_zone.get_start_address() + gui.new_task.get_t_length()
                    n_zone.set_z_length(gui.new_task.get_t_length())
                    n_zone.set_name(gui.new_task.get_name())
                    gui.zone_lst.insert(gui.zone_lst.index(n_zone) + 1,
                                        cd.zone(rest_start_address, rest_z_length, 'free', None))
                    gui.can_alloc = True
                    break
        if not gui.can_alloc:
            is_dup = False
            for task in gui.wait_task_lst:
                if gui.new_task.get_name() == task.get_name():
                    is_dup = True
            if not is_dup:
                gui.wait_task_lst.append(gui.new_task)
        if gui.can_alloc:
            gui.task_lst.append(gui.new_task)
        print('-------------------------------------')
        print('分配任务之后的内存空间')
        print('起始\t长度\t状态\t作业名称')
        for i in gui.zone_lst:
            print('{}\t\t{}\t\t{}\t{}'.format(i.get_start_address(), i.get_z_length(), i.get_state(), i.get_name()))
    if gui.is_best or gui.is_worst:
        gui.can_alloc = False
        start_address_length_lst = sort_zone_length(gui)
        for i in start_address_length_lst:
            if gui.new_task.get_t_length() <= i[1] and i[2] == 'free':
                revise_zone(gui, i[0], gui.new_task)
                gui.can_alloc = True
                break
        if not gui.can_alloc:
            is_dup = False
            for task in gui.wait_task_lst:
                if gui.new_task.get_name() == task.get_name():
                    is_dup = True
            if not is_dup:
                gui.wait_task_lst.append(gui.new_task)
        if gui.can_alloc:
            gui.task_lst.append(gui.new_task)
        print('-------------------------------------')
        print('分配后的内存空间')
        print('起始\t长度\t状态\t作业名称')
        for i in gui.zone_lst:
            print('{}\t\t{}\t\t{}\t{}'.format(i.get_start_address(), i.get_z_length(), i.get_state(), i.get_name()))


# 分配空间，在画布中可视化
def allocate_in_cvs(gui):
    gui.update()
    gui.clear_cvs()
    gui.draw_zone()
    gui.task_index_lst = tf.find_used_zone(gui.zone_lst, gui.new_task)
    visual_task(gui, gui.task_index_lst)


# 画任务，即带填充颜色的矩形'magenta'
def visual_task(gui, lst):
    rect_x1, rect_y1, rect_x2, rect_y2 = gui.hline_pos_lst[lst[0]][0] + 1.5, gui.hline_pos_lst[lst[0]][1] + 1.5, \
                                         gui.hline_pos_lst[lst[0] + 1][2] - 1.5, gui.hline_pos_lst[lst[0] + 1][
                                             3] - 1.5
    text_x, text_y = (rect_x1 + rect_x2) / 2, (rect_y1 + rect_y2) / 2
    task_rect = gui.cvs.create_rectangle(rect_x1, rect_y1, rect_x2, rect_y2, fill='magenta')
    task_name = gui.cvs.create_text(text_x, text_y, text=lst[1], font=('微软雅黑', 10, 'bold'))
    gui.task_rect_text_lst.append([task_rect, task_name, lst[1]])


# 在最佳适配算法下，对内存的长度进行排序
def sort_zone_length(gui):
    start_address_length_lst = []
    for i in range(0, len(gui.zone_lst)):
        start_address_length_lst.append(
            (gui.zone_lst[i].get_start_address(), gui.zone_lst[i].get_z_length(), gui.zone_lst[i].get_state()))
    if gui.is_best:
        start_address_length_lst.sort(key=lambda i: i[1])
    if gui.is_worst:
        start_address_length_lst.sort(key=lambda i: -i[1])
    return start_address_length_lst


# 定位并且修改zone_lst中的已分配的指定zone
def revise_zone(gui, start_address, task):
    for n_zone in gui.zone_lst:
        if n_zone.get_start_address() == start_address:
            n_zone.set_state('used')
            n_zone.set_name(task.get_name())
            rest_t_length = n_zone.get_z_length() - task.get_t_length()
            n_zone.set_z_length(task.get_t_length())
            index = gui.zone_lst.index(n_zone) + 1
            gui.zone_lst.insert(index,
                                cd.zone(n_zone.get_start_address() + task.get_t_length(), rest_t_length, 'free', None))
            if rest_t_length == 0:
                gui.zone_lst.pop(index)
            break
