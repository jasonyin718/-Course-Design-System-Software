import tkinter as tk
import tkinter.filedialog
import itertools
import class_def as cd
import operation_allocation as az
import operation_wait_task as ow


# 打开文件路径选择窗口
def open_file_win(gui):
    gui.file_name = tk.filedialog.askopenfilename()
    if not gui.file_name == '':
        gui.btn_welcome['state'] = 'normal'
        gui.file_name_label.config(text=gui.file_name)


# 将空闲区域的数据存储到列表中
def op_file_content(gui):
    gui.zone_lst.clear()
    with open(gui.file_name, 'r') as f:
        for line in itertools.islice(f, 1, None):
            ls = line.split()
            one_zone = cd.zone(int(ls[0]), int(ls[1]), 'free', None)
            gui.zone_lst.append(one_zone)
    f.close()
    gui.zone_lst_len = len(gui.zone_lst)
    print('-------------------------------------')
    print('初始化的内存空间')
    print('起始\t长度\t状态\t作业名称')
    for i in gui.zone_lst:
        print('{}\t\t{}\t\t{}\t{}'.format(i.get_start_address(), i.get_z_length(), i.get_state(), i.get_name()))


# 读入任务序列
def draw_task(gui):
    with open('task_file', 'r') as f:
        lines = f.readlines()
        for line in lines:
            now_line = line.split()
            gui.new_task = cd.task(now_line[0], int(now_line[1]), int(now_line[2]))
            print(gui.new_task.get_name(), gui.new_task.get_t_length(), gui.new_task.get_op_time())
            az.allocate(gui)
            if gui.can_alloc:
                gui.can_alloc = False
    f.close()
    ow.put_history_on_win(gui)


def draw_wait_task(gui):
    with open('wait_task_file', 'r', encoding='UTF-8') as f:
        lines = f.readlines()
        for line in lines:
            now_line = line.split()
            gui.new_task = cd.task(now_line[0], int(now_line[1]), int(now_line[2]) + gui.now_time)
            az.allocate(gui)
            if gui.can_alloc:
                gui.can_alloc = False
                ow.del_this_wait_task(gui, gui.new_task)
                ow.write_wait_file(gui)
