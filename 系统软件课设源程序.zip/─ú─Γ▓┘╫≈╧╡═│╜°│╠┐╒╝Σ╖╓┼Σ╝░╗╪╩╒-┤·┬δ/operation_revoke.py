import copy as cpy


def delete_in_cvs(gui, i):
    gui.cvs.delete(gui.task_rect_text_lst[i][0])
    gui.cvs.delete(gui.task_rect_text_lst[i][1])
    gui.task_rect_text_lst.pop(i)


def revoke_in_cvs(gui, task_name):
    for i in range(0, len(gui.task_rect_text_lst)):
        if gui.task_rect_text_lst[i][-1] == task_name:
            delete_in_cvs(gui, i)
            break
    for j in range(0, len(gui.zone_lst)):
        index = cpy.deepcopy(j)
        if gui.zone_lst[j].get_name() == task_name:
            gui.zone_lst[j].set_name(None)
            gui.zone_lst[j].set_state('free')
            if (index - 1) >= 0 and gui.zone_lst[index - 1].get_state() == 'free':
                merge_above(gui, index)
                index = index - 1
            if (index + 1) <= len(gui.zone_lst) - 1 and gui.zone_lst[index + 1].get_state() == 'free':
                merge_beneath(gui, index)
            break
    gui.clear_cvs()
    gui.draw_zone()
    print('-------------------------------------')
    print('撤销之后的内存空间')
    print('起始\t长度\t状态\t作业名称')
    for i in gui.zone_lst:
        print('{}\t\t{}\t\t{}\t{}'.format(i.get_start_address(), i.get_z_length(), i.get_state(), i.get_name()))
    print('gui.task_rect_text_lst的长度：', len(gui.task_rect_text_lst))


def revoke_in_DS(gui):
    for i in range(0, len(gui.task_lst)):
        if gui.task_lst[i].get_op_time() == gui.now_time:
            gui.task_lst.pop(i)
            break


# 向上合并
def merge_above(gui, index):
    gui.zone_lst[index].set_start_address(gui.zone_lst[index - 1].get_start_address())
    gui.zone_lst[index].set_z_length(gui.zone_lst[index].get_z_length() + gui.zone_lst[index - 1].get_z_length())
    gui.zone_lst.pop(index - 1)


# 向下合并
def merge_beneath(gui, index):
    gui.zone_lst[index].set_z_length(gui.zone_lst[index].get_z_length() + gui.zone_lst[index + 1].get_z_length())
    gui.zone_lst.pop(index + 1)
