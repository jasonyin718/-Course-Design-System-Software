import tkinter as tk
import operation_file as of
import class_def as cd

def main():
    root = tk.Tk()
    v = tk.IntVar()
    gui = GUI(root, v)
    gui.mainloop()


class GUI(tk.Frame):
    # 构造函数
    def __init__(self, welcome_win, v):
        tk.Frame.__init__(self, welcome_win)
        self.file_name = ''
        self.init_welcomeWin(v, welcome_win)

    # 初始化欢迎窗口
    def init_welcomeWin(self, v, welcome_win):
        # 欢迎窗口定义
        self.welcome_win = welcome_win
        self.welcome_win.title('欢迎')
        self.welcome_win.geometry('400x330+550+250')
        self.init_rd_btn()
        # 初始化title
        self.label_welcome1 = tk.Label(self.welcome_win, text='欢迎进入内存可视化界面', font=('微软雅黑', 15))
        self.label_welcome2 = tk.Label(self.welcome_win, text='内存分配算法：')
        self.label_welcome1.pack(anchor='n')
        self.label_welcome2.place(x=50, y=50)
        # 初始化欢迎界面的RadioButton
        v.set(0)
        fuc_list = [(self.rd_btn_first, '首次适配', self.set_btn_first, 1),
                    (self.rd_btn_best, '最佳适配', self.set_btn_best, 2),
                    (self.rd_btn_worst, '最差适配', self.set_btn_worst, 3)]
        for btn, str_rd, func, var in fuc_list:
            btn = tk.Radiobutton(self.welcome_win, text=str_rd, variable=v, value=var, command=func)
            btn.place(x=150, y=40 + 40 * var)
        # 初始化welcome_win的Button
        self.btn_choose_ept_file = tk.Button(self.welcome_win, text='选择【空闲分区】', bg='LightBlue',
                                             command=lambda: of.open_file_win(self))
        self.btn_choose_ept_file.place(x=60, y=220)
        self.file_name_label = tk.Label(self.welcome_win, text=self.file_name)
        self.file_name_label.place(x=180, y=223)
        self.btn_welcome = tk.Button(self.welcome_win, text='进 入', bg='LightBlue', state='disabled')
        self.btn_welcome.place(x=120, y=270)
        self.btn_exit = tk.Button(self.welcome_win, text='退 出', bg='LightBlue', command=self.exit_welcome_win)
        self.btn_exit.place(x=200, y=270)

    # 初始化欢迎界面的RadioButton
    def init_rd_btn(self):
        self.rd_btn_first = None
        self.rd_btn_best = None
        self.rd_btn_worst = None

    # 初始化各个组件
    def init_main_win_widget(self):
        self.init_attr()
        self.clear_wait_file()
        self.welcome_win.withdraw()
        self.init_main_win()
        of.op_file_content(self)  # 读取空闲区域分区文件
        self.init_cvs()
        of.draw_task(self)
        self.timer_thread = cd.timerThread(self)  # 创建时间线程类的对象
        self.revoke_thread = cd.revokeThread(self)
        self.timer_thread.start()  # 启动时间线程
        self.revoke_thread.start()

    def clear_wait_file(self):
        with open('wait_task_file', 'r+', encoding='UTF-8') as f:
            f.truncate()
        f.close()

    # 初始化属性
    def init_attr(self):
        self.new_task = None
        self.now_time = 0
        self.rate = 0
        self.task_len_lst = []
        self.wait_task_lst = []
        self.task_lst = []
        self.zone_lst = []
        self.zone_lst_len = 0
        self.task_index_lst = []
        self.task_rect_text_lst = []
        self.can_alloc = False

    # 设置'首次适配'的RadioButton
    def set_btn_first(self):
        self.is_first = True
        self.is_best = False
        self.is_worst = False
        self.btn_welcome['command'] = self.init_main_win_widget
        print("已选择首次适配")

    # 设置'最佳适配'的RadioButton
    def set_btn_best(self):
        self.is_first = False
        self.is_best = True
        self.is_worst = False
        self.btn_welcome['command'] = self.init_main_win_widget
        print("已选择最佳适配")

    # 设置'最差适配'的RadioButton
    def set_btn_worst(self):
        self.is_first = False
        self.is_best = False
        self.is_worst = True
        self.btn_welcome['command'] = self.init_main_win_widget
        print("已选择最差适配")

    # 初始化主界面
    def init_main_win(self):
        self.main_win = tk.Tk()
        self.main_win.geometry('1100x700+300+50')
        self.main_win.title('内存分配可视化')

    # 初始化画布
    def init_cvs(self):
        # 滑动条定义和配置
        self.cvs = tk.Canvas(self.main_win, bg='LightGrey', width=900, height=660)
        self.cvs.place(x=150, y=10)
        self.cvs['scrollregion'] = (0, 0, 900, 2000)
        v_bar = tk.Scrollbar(self.main_win, orient='vertical')
        v_bar.pack(side='right', fill='y')
        v_bar.config(command=self.cvs.yview)
        self.cvs.config(yscrollcommand=v_bar.set)
        self.draw_zone()
        self.cvs1 = tk.Canvas(self.main_win, bg='Grey', relief='sunken', width=200, height=300)
        self.cvs1.place(x=155, y=150)
        self.cvs2 = tk.Canvas(self.main_win, bg='LightGrey', width=150, height=50)
        self.cvs2.place(x=155, y=50)

    # 画内存
    def draw_zone(self):
        title_x, title_y = 460, 50
        self.hline_lst = [None]  # 存储横线的数据结构的列表
        self.hline_pos_lst = []  # 存储横线的起点和终点的列表
        self.cvs_all_ele_lst = []  # 画布上所有的元素
        # 画zone矩形的参数
        rect_x1, rect_y1, rect_x2, rect_y2 = 310, 100, 610, 310 + 90 * self.zone_lst_len
        self.rect_width, self.rect_height = rect_x2 - rect_x1, rect_y2 - rect_y1  # 将rectangle的宽和高存起来
        # 放大倍数
        self.rate = 10
        i = 0
        '''画标题'''
        if self.is_first:
            self.first_title = self.cvs.create_text(title_x, title_y, text='首次适配算法可视化界面', anchor='c',
                                                    font=('微软雅黑', 20))
            self.cvs_all_ele_lst.append(self.first_title)
        if self.is_best:
            self.best_title = self.cvs.create_text(title_x, title_y, text='最佳适配算法可视化界面', anchor='c',
                                                   font=('微软雅黑', 20))
            self.cvs_all_ele_lst.append(self.best_title)
        if self.is_worst:
            self.worst_title = self.cvs.create_text(title_x, title_y, text='最差适配算法可视化界面', anchor='c',
                                                    font=('微软雅黑', 20))
            self.cvs_all_ele_lst.append(self.worst_title)
        '''画zone'''
        now_line_x1, now_line_y1, now_line_x2, now_line_y2 = rect_x1, rect_y1, rect_x2, rect_y1
        hline = self.cvs.create_line(now_line_x1, now_line_y1, now_line_x2, now_line_y2, width=3)
        start_address_label = self.cvs.create_text(now_line_x1 - 30, now_line_y1, text=0, font=('微软雅黑', 15))
        self.hline_lst.append([hline, start_address_label, None])
        self.hline_pos_lst.append([now_line_x1, now_line_y1, now_line_x2, now_line_y2])
        # 将元素加到cvs_all_lst中
        self.cvs_all_ele_lst.append(hline)
        self.cvs_all_ele_lst.append(start_address_label)

        while i < len(self.zone_lst):
            now_line_y1 += self.zone_lst[i].get_z_length() * self.rate
            now_line_y2 += self.zone_lst[i].get_z_length() * self.rate
            self.hline_pos_lst.append([now_line_x1, now_line_y1, now_line_x2, now_line_y2])
            hline = self.cvs.create_line(now_line_x1, now_line_y1, now_line_x2, now_line_y2, width=3)
            if i != len(self.zone_lst) - 1:
                label_text = self.zone_lst[i + 1].get_start_address()
                start_address_label = self.cvs.create_text(now_line_x1 - 30, now_line_y1, text=label_text,
                                                           font=('微软雅黑', 15))
            else:
                label_text = self.zone_lst[i].get_start_address() + self.zone_lst[i].get_z_length()
                start_address_label = self.cvs.create_text(now_line_x1 - 30, now_line_y1, text=label_text,
                                                           font=('微软雅黑', 15))
            length_label = self.cvs.create_text(now_line_x2 + 20, (now_line_y2 + self.hline_pos_lst[i][3]) / 2,
                                                text=self.zone_lst[i].get_z_length(), font=('微软雅黑', 10, 'bold'))
            self.hline_lst.append([hline, start_address_label, length_label])
            self.cvs_all_ele_lst.append(length_label)
            # 将元素加到cvs_all_lst中
            self.cvs_all_ele_lst.append(hline)
            self.cvs_all_ele_lst.append(start_address_label)
            i += 1
        i -= 1
        '''画竖线'''
        vline1 = self.cvs.create_line(rect_x1, rect_y1, now_line_x1, now_line_y1, width=3)
        vline2 = self.cvs.create_line(rect_x2, rect_y1, now_line_x2, now_line_y2, width=3)
        # 将元素加到cvs_all_lst中
        self.cvs_all_ele_lst.append(vline1)
        self.cvs_all_ele_lst.append(vline2)

    # 删除画布中所有的元素
    def clear_cvs(self):
        for i in self.cvs_all_ele_lst:
            self.cvs.delete(i)

    # 从可视化界面返回到欢迎界面
    def back_to_welcomeWin(self):
        self.timer_thread.ternimate()
        self.revoke_thread.ternimate()
        self.main_win.withdraw()
        self.welcome_win.update()
        self.welcome_win.deiconify()
        self.welcome_win.wm_attributes('-topmost', 1)

    # 彻底退出整个软件(从欢迎界面)
    def exit_welcome_win(self):
        self.welcome_win.quit()

    # 从主界面退出
    def exit_main_win(self):
        self.timer_thread.ternimate()
        self.revoke_thread.ternimate()
        self.main_win.quit()


if __name__ == '__main__':
    main()
