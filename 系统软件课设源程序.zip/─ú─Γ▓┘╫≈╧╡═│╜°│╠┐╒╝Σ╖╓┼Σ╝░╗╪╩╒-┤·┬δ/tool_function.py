'''
    工具函数库
'''


# 将str列表转化为int列表
def convert_str_int(lst):
    for i in range(0, len(lst)):
        lst[i] = int(lst[i])


# 找到状态为'used'的空间，返回其在列表中的下标
def find_used_zone(lst, task):
    for i in range(0, len(lst)):
        if lst[i].get_state() == 'used' and lst[i].get_name() == task.get_name():
            index_lst = [i, lst[i].get_name()]
            return index_lst
