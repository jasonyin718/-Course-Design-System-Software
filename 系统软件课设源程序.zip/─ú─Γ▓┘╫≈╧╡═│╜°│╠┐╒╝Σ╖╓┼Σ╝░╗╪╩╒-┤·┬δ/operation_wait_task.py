import tkinter as tk
import itertools as it


def del_this_wait_task(gui, new_task):
    for i in range(0, len(gui.wait_task_lst)):
        if gui.wait_task_lst[i].get_name() == new_task.get_name():
            gui.wait_task_lst.pop(i)
            break


def put_history_on_win(gui):
    write_wait_file(gui)
    draw_on_cvs(gui)


def write_wait_file(gui):
    with open('wait_task_file', 'r+', encoding='UTF-8') as f:
        f.truncate()
        for task in gui.wait_task_lst:
            tmp = ''
            tmp += task.get_name() + ' ' * 4 + str(task.get_t_length()) + ' ' * 4 + str(
                task.get_op_time()) + '\n'
            f.writelines(tmp)
    f.close()


def draw_on_cvs(gui):
    gui.cvs1.delete(tk.ALL)
    text_pos_x, text_pos_y = 10, 80
    gui.cvs1.create_text(50, 30, text="任务等待队列", anchor='w', justify='left', font=('微软雅黑', 13))
    with open('wait_task_file', 'r', encoding='UTF-8') as f:
        for line in it.islice(f, 0, None):
            gui.cvs1.create_text(text_pos_x + 50, text_pos_y, text=line, anchor='w', justify='left', font=('微软雅黑', 13))
            text_pos_y += 50
    f.close()
